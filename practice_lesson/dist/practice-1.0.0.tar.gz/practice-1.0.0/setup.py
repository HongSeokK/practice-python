from setuptools import setup

setup(
    name='practice',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://google.com',
    license='free',
    author='ghdtj',
    author_email='',
    description='practice package'
)
